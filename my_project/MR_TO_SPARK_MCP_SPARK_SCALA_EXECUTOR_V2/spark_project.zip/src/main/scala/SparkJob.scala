import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

object InvSalesAggJobSpark {
  def main(args: Array[String]): Unit = {
    if (args.length != 4) {
      System.err.println("Usage: InvSalesAggJobSpark <sales_base_path> <inventory_base_path> <output_base_path> <date>")
      System.err.println("Example: InvSalesAggJobSpark /data/sales /data/inventory /output/inv_sales_agg 2023-07-02")
      System.err.println("Will read from:")
      System.err.println(" -/data/sales/sale_date=<date>")
      System.err.println(" -/data/inventory/date=<date>")
      System.err.println(" -Output to: /output/inv_sales_agg/event_date=<date>")
      System.exit(1)
    }

    val salesBasePath = args(0)
    val inventoryBasePath = args(1)
    val outputBasePath = args(2)
    val targetDate = args(3)

    val salesInputPath = s"$salesBasePath/sale_date=$targetDate"
    val inventoryInputPath = s"$inventoryBasePath/date=$targetDate"
    val outputPath = s"$outputBasePath/event_date=$targetDate"

    val spark = SparkSession.builder
      .appName(s"Inventory Sales Aggregation - $targetDate")
      .getOrCreate()

    try {
      println("=== Job Configuration ===")
      println(s"Sales Input Path: $salesInputPath")
      println(s"Inventory Input Path: $inventoryInputPath")
      println(s"Output Path: $outputPath")
      println(s"Target Date: $targetDate")
      println("========================")

      // Read sales data and select/rename required columns
      val salesDF = spark.read.parquet(salesInputPath)
        .select(
          col("Item_Identifier").as("item_identifier"),
          col("Outlet_Identifier").as("outlet_identifier"),
          col("Quantity").as("sold_quantity")
        )

      // Read inventory data and select/rename required columns
      val inventoryDF = spark.read.parquet(inventoryInputPath)
        .select(
          col("Item_Identifier").as("item_identifier"),
          col("Outlet_Identifier").as("outlet_identifier"),
          col("Stock_Quantity").as("stock_quantity")
        )

      // Perform an inner join on item_identifier and outlet_identifier
      // This replicates the reducer's "if (hasInventory && hasSales)" logic
      val joinedDF = salesDF.join(
        inventoryDF,
        Seq("item_identifier", "outlet_identifier"),
        "inner"
      )

      // Group by item, outlet, and stock quantity (assuming stock_quantity is unique per item/outlet for the date)
      // Then sum the sold_quantity for each group
      val aggregatedDF = joinedDF
        .groupBy("item_identifier", "outlet_identifier", "stock_quantity")
        .agg(sum("sold_quantity").as("sold_quantity"))
        .select("item_identifier", "outlet_identifier", "stock_quantity", "sold_quantity")

      // Write the aggregated data to Parquet format, partitioned by event_date
      aggregatedDF.write
        .mode("overwrite")
        .option("compression", "snappy")
        .parquet(outputPath)

      println("\n=== Job Completed Successfully! ===")
      println(s"Output written to: $outputPath")

    } catch {
      case e: Exception =>
        System.err.println("\n=== Job Failed! ===")
        e.printStackTrace()
        System.exit(1)
    } finally {
      spark.stop()
    }
  }
}