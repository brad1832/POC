import org.apache.spark.sql.{SparkSession, DataFrame, SaveMode}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._

object InvSalesAggJob {
  def main(args: Array[String]): Unit = {
    val salesBasePath = args(0)
    val inventoryBasePath = args(1)
    val outputBasePath = args(2)
    val targetDate = args(3)

    val salesInputPath = s"$salesBasePath/sale_date=$targetDate"
    val inventoryInputPath = s"$inventoryBasePath/date=$targetDate"
    val outputPath = s"$outputBasePath/event_date=$targetDate"

    val spark = SparkSession.builder
      .appName(s"Inventory Sales Aggregation - $targetDate")
      .getOrCreate()

    val salesInputSchema = StructType(Array(
      StructField("Item_Identifier", StringType, nullable = false),
      StructField("Outlet_Identifier", StringType, nullable = false),
      StructField("Quantity", LongType, nullable = false)
    ))

    val inventoryInputSchema = StructType(Array(
      StructField("Item_Identifier", StringType, nullable = false),
      StructField("Outlet_Identifier", StringType, nullable = false),
      StructField("Stock_Quantity", LongType, nullable = false)
    ))

    val salesDF = spark.read
      .schema(salesInputSchema)
      .parquet(salesInputPath)
      .select(
        col("Item_Identifier").cast(StringType).as("item_identifier"),
        col("Outlet_Identifier").cast(StringType).as("outlet_identifier"),
        col("Quantity").cast(LongType).as("quantity")
      )

    val aggregatedSalesDF = salesDF
      .groupBy("item_identifier", "outlet_identifier")
      .agg(
        sum("quantity").cast(LongType).as("sold_quantity")
      )

    val inventoryDF = spark.read
      .schema(inventoryInputSchema)
      .parquet(inventoryInputPath)
      .select(
        col("Item_Identifier").cast(StringType).as("item_identifier"),
        col("Outlet_Identifier").cast(StringType).as("outlet_identifier"),
        col("Stock_Quantity").cast(LongType).as("stock_quantity")
      )

    val aggregatedInventoryDF = inventoryDF
      .groupBy("item_identifier", "outlet_identifier")
      .agg(
        max("stock_quantity").cast(LongType).as("stock_quantity")
      )

    val joinedDF = aggregatedSalesDF.join(
      aggregatedInventoryDF,
      Seq("item_identifier", "outlet_identifier"),
      "inner"
    )

    val finalDF = joinedDF.select(
      col("item_identifier"),
      col("outlet_identifier"),
      col("stock_quantity"),
      col("sold_quantity")
    )

    finalDF.write
      .mode(SaveMode.Overwrite)
      .option("compression", "snappy")
      .parquet(outputPath)

    spark.stop()
  }
}